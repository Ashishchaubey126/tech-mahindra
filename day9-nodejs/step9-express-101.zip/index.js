let express = require("express");
let app = express();

// routes
app.get("/",(req, res)=>{
    res.render("home.pug",{
        company : "Tech Mahindra India",
        avengers : ['Ironman','Hulk','Spiderman','Antman','Vision']
    });
});

app.listen(3030,(err)=>{
    if(err){console.log("Error : ",err)}
    else{ console.log("server is now live on localhost:3030")}
});
