const express = require("express");
const fs = require("fs");
const app = express();
app.use(express.json());

let herodata = fs.readFileSync(__dirname+"/data/heroes.json");
let herostrinData = JSON.parse(herodata);

app.listen(2525);

app.use(express.static(__dirname+"/public"));
// app.get("/", (req, res) => { res.sendFile(__dirname+"/public/index.html")});
app.get("/data", (req, res) => { 
    // res.sendFile(__dirname+"/data/heroes.json");
       res.send(herostrinData);
});
app.post("/data", (req, res) => { 
    res.send({"message": "post message recieved"});
    console.log(req.body);
    console.log("#############################");
    herostrinData.data.push(req.body);
    console.log(herostrinData);
});
console.log("Server is now live on localhost:2525");