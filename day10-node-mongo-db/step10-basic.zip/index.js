const express = require("express");
const app = express();
const externalData = require("./data.json");

app.use(express.urlencoded({extended : true}));

let parsedExtData = externalData.data;

app.get("/", (req, res)=>{
    res.render("home.pug",{
        herodata : parsedExtData
    })
});

app.post("/", (req, res)=>{
    parsedExtData.push(req.body.newheroname);
    res.redirect("/");
    res.end();
})

app.listen(2525);
console.log("Server is now live on localhost:2525");